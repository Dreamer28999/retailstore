﻿using MyRetailStore.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace MyRetailStore.ViewModels
{
    class ChangeUsrAndPasswd : UserManagementViewModel
    {
        
        public ChangeUsrAndPasswd()
        {
        }
       
    }
}
